import collections
import math
import pickle
import traceback as tb
import pandas as pd
from sensor_msgs.msg import Image
from vision_msgs.msg import Detection2DArray, Detection2D, ObjectHypothesis, Classification
from simple_tracker_shared.qos_profiles import get_topic_publisher_qos_profile, get_topic_subscriber_qos_profile


from std_msgs.msg import Header
import message_filters
from rclpy.node import Node
from rclpy.qos import QoSProfile
from rclpy import Parameter
from rclpy.executors import SingleThreadedExecutor
from rclpy import init, shutdown
import rclpy
from typing import List


# from sky360_node_base import ConfiguredNode, NodeRunner
from simple_tracker_shared.configured_node import ConfiguredNode
from simple_tracker_shared.node_runner import NodeRunner
# from TrackingStateEnum import TrackingStateEnum
from enum import IntEnum

class DayNightEnum(IntEnum):
    Unknown = 0
    Day = 1
    Night = 2

class TrackingStateEnum(IntEnum):
    ProvisionaryTarget = 1
    ActiveTarget = 2
    LostTarget = 3

class TimeSeriesClassificationNode(ConfiguredNode):
    def __init__(self, subscriber_qos_profile: QoSProfile, publisher_qos_profile: QoSProfile):
        super().__init__('time_series_classification_provider')
        self.pub_classification = self.create_publisher(Classification, 'sky360/timeseries_classification', publisher_qos_profile)
        self.sub_tracker_detections = message_filters.Subscriber(self, Detection2DArray, 'sky360/tracker/detections', qos_profile=subscriber_qos_profile)
        # Add a new variable to store the time series data
        self.time_series_data = collections.defaultdict(list)
        self.sub_tracker_detections.registerCallback(self.callback)  # This line has been updated
        self.get_logger().info(f'{self.get_name()} node is up and running.')
        self.min_data_points = 10  # Adjust this value according to your requirements

    def config_list(self) -> List[str]:
        return ['timeSeriesTestSetting']

    def callback(self, msg_detection_array: Detection2DArray):
        if msg_detection_array is not None:
            try:
                classification_msg = Classification()
                classification_msg.header = msg_detection_array.header
                classification_msg.results = []
                for detection in msg_detection_array.detections:
                    id_arr = detection.id.split("-")
                    id = id_arr[0]
                    tracking_state = TrackingStateEnum(int(id_arr[1]))
                    if tracking_state == TrackingStateEnum.ActiveTarget:
                        (x, y, w, h) = decode_bbox_msg(detection.bbox)
                        center_x, center_y = x + w / 2, y + h / 2
                        # Update the time series data for the current object
                        self.time_series_data[id].append((center_x, center_y))
                        # If enough data points have been collected, perform time series classification
                        if len(self.time_series_data[id]) >= min_data_points:
                            prediction = self.classify_time_series(self.time_series_data[id])
                            hypothesis = ObjectHypothesis()
                            hypothesis.class_id = f'{id}-{prediction}'
                            classification_msg.results.append(hypothesis)
                self.pub_classification.publish(classification_msg)
            except Exception as e:
                self.get_logger().error(f'Exception during time series classification. Error: {e}.')
                self.get_logger().error(tb.format_exc())
    def load_model(self, model_path: str):
        with open(model_path, 'rb') as f:
            self.model = pickle.load(f)
    def classify_time_series(self, time_series_data):
        # Preprocess the time series data if necessary
        processed_data = self.preprocess_time_series_data(time_series_data)
        # Classify the time series data using the Catch-22 model
        prediction = self.model.predict(processed_data)
        return prediction
    def preprocess_time_series_data(self, time_series_data):
        # Extract direction_changes and distances from time_series_data
        direction_changes = [data["direction_change"] for data in time_series_data]
        distances = [data["distance"] for data in time_series_data]
        # Clean the direction_changes list by replacing NaNs with 0
        direction_changes_cleaned = [0 if math.isnan(dc) else dc for dc in direction_changes]
        # Prepare DataFrame with input data for classification model
        df1 = pd.DataFrame(direction_changes_cleaned, columns=["Direction_changes"])
        df2 = pd.DataFrame(distances, columns=["Distances"])
        X_test = pd.concat([df1, df2], axis=1)
        return X_test
    def update_time_series_data(self, new_bbox, timestamp):
        if len(self.bbox_history) > 0:
            prev_bbox, prev_timestamp = self.bbox_history[-1]
            # Calculate distance
            distance = self.calculate_distance(new_bbox, prev_bbox)
            # Calculate direction change if there are at least 4 bounding boxes in history
            if len(self.bbox_history) >= 4:
                prev_bbox_4, _ = self.bbox_history[-4]
                direction_change = self.calculate_direction_change(prev_bbox, prev_bbox_4, new_bbox)
            else:
                direction_change = None
            # Calculate time difference
            time_diff = (timestamp - prev_timestamp).nanoseconds * 1e-9
            # Add the new data to time_series_data
            self.time_series_data.append({"distance": distance, "direction_change": direction_change, "time_diff": time_diff})
            # Remove the oldest data if the length of time_series_data exceeds the sequence_length
            if len(self.time_series_data) > self.sequence_length:
                self.time_series_data.pop(0)
        self.bbox_history.append((new_bbox, timestamp))
def main(args=None):
    rclpy.init(args=args)
    subscriber_qos_profile = get_topic_subscriber_qos_profile()
    publisher_qos_profile = get_topic_publisher_qos_profile()

    node = TimeSeriesClassificationNode(subscriber_qos_profile, publisher_qos_profile)
    # Load the trained Catch-22 model
    model_path = 'resources/model_Catch22_bird_plant_plane_10.pkl'
    node.load_model(model_path)
    runner = NodeRunner(node)
    runner.run()

if __name__ == '__main__':
    main()