from setuptools import setup, find_packages

with open("requirements.txt") as f:
    required = f.read().splitlines()

setup(
    name="Kinematics",
    version="0.1.0",
    description="The Kinematics package subscribes to a image stream via a ROS2 topic, classifies the image using a trained model, then overlays the classification and publishes the an image stream with including the classification overlayed on the image.",
    author="Your Name",
    author_email="your.email@example.com",
    url="https://github.com/Sky360-Repository/kinematics.git",
    packages=find_packages(),
    install_requires=required,
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
    ],
)
